import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-control-list',
  templateUrl: './control-list.component.html',
  styleUrls: ['./control-list.component.scss']
})
export class ControlListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
